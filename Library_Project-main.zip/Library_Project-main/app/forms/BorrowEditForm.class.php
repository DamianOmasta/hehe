<?php

namespace app\forms;

class BorrowEditForm {
	public $id_borrowed;
	public $date_of_borrow;
	public $date_to_return;
	public $books_id_book;
	public $users_id_user;
}