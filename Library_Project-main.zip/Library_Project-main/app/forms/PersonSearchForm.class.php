<?php

namespace app\forms;

class PersonSearchForm {
	public $id_user;
} 