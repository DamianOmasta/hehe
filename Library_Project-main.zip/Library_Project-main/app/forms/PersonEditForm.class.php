<?php

namespace app\forms;

class PersonEditForm {
	public $id_user;
	public $login;
	public $password;
	public $user_type_id_type;
}