<?php

namespace app\forms;

class BorrowSearchForm {
	public $users_id_user;
} 